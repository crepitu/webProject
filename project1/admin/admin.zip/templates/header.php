<?php 
	if(isset($_POST['addQuestion']))
	{
		header('Location: admin/add.php');
	}
?>





<!DOCTYPE html>
<html>
<head>
	<title>TEST PAGE</title>
	<!-- Compiled and minified CSS -->
  <link href="materialize\css\materialize.min.css" rel="stylesheet" >
  <style type="text/css">
	  .brand{
	  	background: #cbb09c !important;
	  }
  	.brand-text{
  		color: #cbb09c !important;
  	}
  	form{
  		max-width: 460px;
  		margin: 20px auto;
  		padding: 20px;
  	}
  </style>
</head>
<body class="grey lighten-4">
	<nav class="white z-depth-0">
    <div class="container">
      <a href="#" class="brand-logo brand-text">ADMIN PAGE</a>
      <ul id="nav-mobile" class="right hide-on-small-and-down">
      </ul>
	</div>
	<br>
	<div class="container">
		<ul>





		</ul>
	</div>
	<br>
	<div class="container">
      



    </div>
	<br>
	<div class="container">
      <ul id="nav-mobile" class="right hide-on-small-and-down">
        <li>
		<input type="submit" name="addQuestion" value="Add Question" class="btn brand z-depth-0" >
		</li>
		<li>
		<input type="submit" name="addSubject" value="Add Subject" class="btn brand z-depth-0">
		</li>
      </ul>
    </div>
  </nav>
</html>