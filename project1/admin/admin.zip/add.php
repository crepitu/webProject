<?php 
$question= '';
	$errors=array('question'=>'');
	if(isset($_POST['submit'])){

		
		
		// check email
		if(empty($_POST['question'])){
			$errors['question']= 'A question is required <br />';
		} 

	 // end POST check

if(array_filter($errors))
{
	
}else
{
	header('Location: index.php');
}
	}
?>

<!DOCTYPE html>
<html>
	
	<?php include('templates/header.php'); ?>

	<section class="container grey-text">
		<h4 class="center">Add a question</h4>
		<form class="white" action="add.php" method="POST">
			<label>Question:</label>
			<input type="text" name="question" value="<?php echo $question ?>">
			<div class="red-text"><?php echo $errors['question']; ?></div>
			<div class="center">
				<input type="submit" name="submit" value="Submit" class="btn brand z-depth-0">
			</div>
		</form>
	</section>

	<?php include('templates/footer.php'); ?>

</html>